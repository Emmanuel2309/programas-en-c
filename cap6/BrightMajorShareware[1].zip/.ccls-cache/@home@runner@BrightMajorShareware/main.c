#include <stdio.h>

int main() {
  float PRE, NPR;

  printf("Ingrese el precio del producto: ");
  scanf("%f", &PRE);

  if (PRE < 1500) {
    NPR = PRE * 1.11;
    printf("\nEl precio ha sido incrementado en un 11%%.\n");
    printf("Nuevo precio: $%.2f\n", NPR);
  }

  return 0;
}